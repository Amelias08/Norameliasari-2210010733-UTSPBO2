
package InventoryApp;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;
import static javax.swing.JFrame.EXIT_ON_CLOSE;

class Barang {
   private String kode;
    private String nama;
    private int jumlah;
    private String kondisi;

    // Konstruktor untuk kelas Barang
    public Barang(String kode, String nama, int jumlah, String kondisi) {
        this.kode = kode;
        this.nama = nama;
        this.jumlah = jumlah;
        this.kondisi = kondisi;
    }

    // Getter dan setter untuk variabel barang
    public String getKode() {
        return kode;
    }

    public String getNama() {
        return nama;
    }

    public int getJumlah() {
        return jumlah;
    }

    public String getKondisi() {
        return kondisi;
    }

    public void setKode(String kode) {
        this.kode = kode;
    }

    public void setNama(String nama) {
        this.nama = nama;
    }

    public void setJumlah(int jumlah) {
        this.jumlah = jumlah;
    }

    public void setKondisi(String kondisi) {
        this.kondisi = kondisi;
    }
}

// Kelas aplikasi utama
public class InventarisApp extends JFrame implements ActionListener {
    private ArrayList<Barang> daftarBarang = new ArrayList<>();
    private JTextField inputKode, inputNama, inputJumlah;
    private JComboBox<String> kondisiComboBox;
    private DefaultListModel<String> listModel;
    private JList<String> barangList;

    // Konstruktor untuk aplikasi
    public InventarisApp() {
        setTitle("Aplikasi Inventaris Barang");
        setSize(500, 400);
        setDefaultCloseOperation(EXIT_ON_CLOSE);

        JPanel panel = new JPanel();
        JButton tambahButton = new JButton("Tambah");
        JButton ubahButton = new JButton("Ubah");
        JButton hapusButton = new JButton("Hapus");

        tambahButton.addActionListener(this);
        ubahButton.addActionListener(this);
        hapusButton.addActionListener(this);

        inputKode = new JTextField(10);
        inputNama = new JTextField(15);
        inputJumlah = new JTextField(5);

        String[] kondisiBarang = {"Baik", "Rusak", "Hilang"};
        kondisiComboBox = new JComboBox<>(kondisiBarang);

        listModel = new DefaultListModel<>();
        barangList = new JList<>(listModel);

        panel.add(new JLabel("Kode Barang:"));
        panel.add(inputKode);
        panel.add(new JLabel("Nama Barang:"));
        panel.add(inputNama);
        panel.add(new JLabel("Jumlah:"));
        panel.add(inputJumlah);
        panel.add(new JLabel("Kondisi:"));
        panel.add(kondisiComboBox);
        panel.add(tambahButton);
        panel.add(ubahButton);
        panel.add(hapusButton);

        JScrollPane scrollPane = new JScrollPane(barangList);
        panel.add(scrollPane);

        add(panel);
        setVisible(true);
    }

    // Metode untuk menangani aksi tombol
    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getActionCommand().equals("Tambah")) {
            String kodeBarang = inputKode.getText();
            String namaBarang = inputNama.getText();
            int jumlahBarang = Integer.parseInt(inputJumlah.getText());
            String kondisiBarang = kondisiComboBox.getSelectedItem().toString();

            if (kodeBarang.isEmpty() || namaBarang.isEmpty() || inputJumlah.getText().isEmpty()) {
                JOptionPane.showMessageDialog(this, "Isi semua informasi barang.", "Peringatan", JOptionPane.WARNING_MESSAGE);
            } else {
                Barang barang = new Barang(kodeBarang, namaBarang, jumlahBarang, kondisiBarang);
                daftarBarang.add(barang);
                refreshDisplay();
                resetFields(); // Reset input fields setelah menambah barang
            }
        } else if (e.getActionCommand().equals("Ubah")) {
            int selectedIndex = barangList.getSelectedIndex(); // Dapatkan indeks barang yang dipilih

            if (selectedIndex != -1) { // Pastikan ada barang yang dipilih
                String kodeBarang = inputKode.getText();
                String namaBarang = inputNama.getText();
                int jumlahBarang = Integer.parseInt(inputJumlah.getText());
                String kondisiBarang = kondisiComboBox.getSelectedItem().toString();

                if (kodeBarang.isEmpty() || namaBarang.isEmpty() || inputJumlah.getText().isEmpty()) {
                    JOptionPane.showMessageDialog(this, "Isi semua informasi barang.", "Peringatan", JOptionPane.WARNING_MESSAGE);
                } else {
                    Barang barang = daftarBarang.get(selectedIndex); // Dapatkan barang yang dipilih
                    barang.setKode(kodeBarang);
                    barang.setNama(namaBarang);
                    barang.setJumlah(jumlahBarang);
                    barang.setKondisi(kondisiBarang);

                    refreshDisplay();
                    resetFields(); // Reset input fields setelah mengubah barang
                }
            } else {
                JOptionPane.showMessageDialog(this, "Pilih barang yang ingin diubah.", "Peringatan", JOptionPane.WARNING_MESSAGE);
            }
        } else if (e.getActionCommand().equals("Hapus")) {
            int selectedIndex = barangList.getSelectedIndex(); // Dapatkan indeks barang yang dipilih

            if (selectedIndex != -1) { // Pastikan ada barang yang dipilih
                int confirm = JOptionPane.showConfirmDialog(this, "Apakah Anda yakin ingin menghapus barang ini?", "Konfirmasi Hapus", JOptionPane.YES_NO_OPTION);

                if (confirm == JOptionPane.YES_OPTION) { // Jika pengguna mengonfirmasi untuk menghapus
                    daftarBarang.remove(selectedIndex); // Hapus barang dari daftar
                    refreshDisplay(); // Perbarui tampilan daftar barang
                }
            } else {
                JOptionPane.showMessageDialog(this, "Pilih barang yang ingin dihapus.", "Peringatan", JOptionPane.WARNING_MESSAGE);
            }
        }
    }

    // Metode untuk memperbarui tampilan daftar barang
    private void refreshDisplay() {
        listModel.clear();
        for (Barang barang : daftarBarang) {
            String dataBarang = "" + barang.getKode() + ". " + barang.getNama() +
                    ", Jumlah = " + barang.getJumlah() + ", Kondisi = " + barang.getKondisi();
            listModel.addElement(dataBarang);
        }
    }

    // Metode untuk mereset nilai input fields setelah penambahan atau pengubahan barang
    private void resetFields() {
        inputKode.setText("");
        inputNama.setText("");
        inputJumlah.setText("");
        kondisiComboBox.setSelectedIndex(0);
    }

    // Metode utama untuk menjalankan aplikasi
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new InventarisApp());
    }
}
